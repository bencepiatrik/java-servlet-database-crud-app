package sk.ukf;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Main")
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public ResultSetMetaData md;
    public Main() {
    	super();
    }
    
    //vykreslenie tabulky
    public String getSQL(String action, String command, boolean addDeleteBtn, boolean addEditBtn, boolean addAddBtn){
		String url = "jdbc:mysql://localhost/piatrik_sh";
		String login = "root";
		String pwd = "";
    	String table = "";
    	int rowCount = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, login, pwd);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(command);
			table += "<table id=\"myTable\" class=\"container w-75 mt-5 table table-striped table-dark table-hover text-center\">";
			md = rs.getMetaData();
			int columnCount = md.getColumnCount();
			table += "<tr>";
				for (int i = 0; i < columnCount; i++) {
					table += "<th scope=\"col\">" + md.getColumnLabel(i + 1) + "</th>";
				}
				if( addDeleteBtn && addEditBtn) {
					table += "<th scope=\"col\">" + "</th>";				
					table += "<th scope=\"col\">" + "</th>";
				} else if(addEditBtn) {
					table += "<th scope=\"col\">" + "</th>";			
				} else if(addDeleteBtn) {
					table += "<th> scope=\"col\"" + "</th>";
				};
			table += "</tr>";
			while (rs.next()) {
				rowCount++; 
				table += "<tr>";
				for (int i = 0; i < columnCount; i++) {
					table += "<td scope=\"row\">" + rs.getString(i + 1) + "</td>";
				}
				if( addDeleteBtn && addEditBtn) {
					table +=  "<td scope=\"row\">" + addFormBtn(action,"post","actionBtn",md.getTableName(1)+"-delete-"+rs.getString("id"), "Zmazat") + "</td>";
					table +=  "<td scope=\"row\">" + addFormBtn(action,"post","actionBtn",md.getTableName(1)+"-edit-"+rs.getString("id")+"-"+rowCount+"-"+columnCount, "Upravit") + "</td>";	
				} else if(addDeleteBtn) {
					table +=  "<td scope=\"row\">" + addFormBtn(action,"post","actionBtn",md.getTableName(1)+"-delete-"+rs.getString("id"), "Zmazat") + "</td>";
				} else if(addEditBtn) {
					table +=  "<td scope=\"row\">" + addFormBtn(action,"post","actionBtn",md.getTableName(1)+"-edit-"+rs.getString("id")+"-"+rowCount+"-"+columnCount, "Upravit") + "</td>";	
				};
			}
			if(addAddBtn) {
				table += "<tr>"
						+ "<td colspan=\"100\">"+addFormBtn(action,"post","actionBtn",md.getTableName(1)+"-add-"+md.getColumnCount(), "Vlozit novy zaznam")+"</td>"
						+ "</tr>";
			};
		table += "</tr>";
			table += "</table>";
		} catch (Exception ex) {
				table = ex.toString();
		}
    	return table;
    };
    
    //pridanie buttonov
    public String addFormBtn(String action, String method, String name, String value, String txt) {
    	String form;
    	if(txt == "Zmazat") {
        	form = "<form action=\""+action+"\" method=\""+method+"\">"
					+"<button class=\"btn btn-outline-danger btn-sm\" type=\"submit\" name=\""+name+"\" value=\""+value+"\">"+ txt +" </button>"
				+ "</form>";
    	} else if (txt == "Upravit") {
        	form = "<form action=\""+action+"\" method=\""+method+"\">"
					+"<button class=\"btn btn-outline-primary btn-sm\" type=\"submit\" name=\""+name+"\" value=\""+value+"\">"+ txt +"</button>"
				+ "</form>";
    	} else if(txt.contains("Vlozit")) {
        	form = "<form action=\""+action+"\" method=\""+method+"\">"
						+"<button class=\"btn btn-outline-success\" type=\"submit\" name=\""+name+"\" value=\""+value+"\">"+ txt +"</button>"
				+ "</form>";    		
    	} else {
        	form = "<form action=\""+action+"\" method=\""+method+"\">"
					+"<button class=\"btn-lg btn-secondary ml-3 mr-3\" type=\"submit\" name=\""+name+"\" value=\""+value+"\">"+ txt +"</button>"
				+ "</form>";
    	};

    	return form;
    };
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//html head
		out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
		out.println("<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">\r\n");
		//bg color
		out.println("<style>html, body{background-color: #cbc9cf;};</style>");
		out.println("<style>form{margin:0;};</style>");
		//joined tabuly bez id
	///	out.print(getSQL("Main","SELECT skladba.id, skladba.nazov, skladba.album, skladba.dlzka, skladba.interpret, skladba.hodnotenie, zanre.nazov_zanru FROM skladba "
		//		+ "LEFT JOIN tab3 ON skladba.nazov = tab3.nazov "
			//	+ "LEFT JOIN zanre ON zanre.nazov_zanru = tab3.nazov_zanru "
				//, true, true, true));
		//btns na dalsie tabulky
		out.println("<div class=\"d-flex justify-content-center mt-5\">"
						+"<a class=\"btn btn-dark btn-lg mr-4\" target=\"_blank\" href=\"displayTab1\">Zobrazenie tab#1 Skladba </a>"
						+"<a class=\"btn btn-dark btn-lg ml-4\" target=\"_blank\" href=\"displayTab2\">Zobrazenie tab#2 Zanre</a>"
					+"</div>");		
		//out.println(getSQL("Main","SELECT * FROM asd", false, false, false));
		out.print(getSQL("Main","SELECT skladba.id, skladba.nazov, skladba.album, skladba.dlzka, skladba.interpret, skladba.hodnotenie, zanre.nazov_zanru FROM skladba "
						+ "LEFT JOIN tab3 ON skladba.nazov = tab3.nazov "
						+ "LEFT JOIN zanre ON zanre.nazov_zanru = tab3.nazov_zanru "
						, true, true, true));
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}

}
 