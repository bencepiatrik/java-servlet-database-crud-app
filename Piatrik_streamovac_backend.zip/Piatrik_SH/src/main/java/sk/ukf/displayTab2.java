package sk.ukf;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class displayTab2
 */
@WebServlet("/displayTab2")
public class displayTab2 extends Main {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displayTab2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			//html head
			out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
			out.println("<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">\r\n");
			//bg color
			out.println("<style>html, body{background-color: #cbc9cf;};</style>");
			out.println(getSQL("displayTab2","SELECT * FROM zanre", true, true, true));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				PrintWriter asd = response.getWriter();
				String preToDo= request.getParameter("actionBtn");
				String toDo[] = preToDo.split("-");
				String table = toDo[0];
				String prikaz = toDo[1];
				String id = toDo[2];
				String prikazSQL = "";
				//maybe public shit
				String url = "jdbc:mysql://localhost/piatrik_sh";
				String login = "root";
				String pwd = "";
				switch(prikaz) {
					case "delete":
							try {
								Connection con = DriverManager.getConnection(url, login, pwd);
								PreparedStatement checkDel = con.prepareStatement("SELECT EXISTS (SELECT tab3.nazov_zanru FROM tab3 WHERE tab3.nazov_zanru = "
										+ "(SELECT zanre.nazov_zanru FROM zanre WHERE id = ?)"
										+ " ) AS checkDelAnswer;");
								checkDel.setString(1, id);
								ResultSet checkDelRs = checkDel.executeQuery();
								checkDelRs.next();
								String checkDelAnswer = checkDelRs.getString(1);
									if(checkDelAnswer.contains("1")) {
										asd.println("<script type=\"text/javascript\">"
												+ "const alertDel = () => alert(\"tento zaznam je uz spajane a pridane do spojovacej tabulky\")"
										+ "</script>");
										asd.println("<script type=\"text/javascript\">"
												+ "alertDel()"
										+ "</script>");							} 
									else {
										PreparedStatement del = con.prepareStatement("DELETE FROM "+table+" WHERE id = "+id+"");
										del.execute();
									};
							} catch (Exception ex) {
								asd.println(ex.toString());
							}
							
						break;
					case "edit": prikazSQL = "";
						break;
				};
		doGet(request, response);
	}

}
