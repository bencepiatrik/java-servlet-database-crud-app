package sk.ukf;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class displayTab1
 */
@WebServlet("/displayTab1")
public class displayTab1 extends Main {
	private static final long serialVersionUID = 1L;
	public ResultSetMetaData tabMd;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displayTab1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		//html head
		out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
		out.println("<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">\r\n");
		//bg color
		out.println("<style>html, body{background-color: #cbc9cf;};</style>");
		out.println("<style>form{margin:0;};</style>");

		out.println(getSQL("displayTab1","SELECT * FROM skladba", true, true, true));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter asd = response.getWriter();

		String preToDo= request.getParameter("actionBtn");
		if(preToDo == null) {
			doGet(request, response);
		};
		String toDo[] = preToDo.split("-");
		String table = toDo[0];
		String prikaz = toDo[1];
		String id = toDo[2];
		
		String url = "jdbc:mysql://localhost/piatrik_sh";
		String login = "root";
		String pwd = "";
		switch(prikaz) {
			case "delete":
					try {
						Connection con = DriverManager.getConnection(url, login, pwd);
						PreparedStatement checkDel = con.prepareStatement("SELECT EXISTS (SELECT tab3.nazov FROM tab3 WHERE tab3.nazov = "
								+ "(SELECT skladba.nazov FROM skladba WHERE id = ?)"
								+ " ) AS checkDelAnswer;");
						checkDel.setString(1, id);
						ResultSet checkDelRs = checkDel.executeQuery();
						checkDelRs.next();
						String checkDelAnswer = checkDelRs.getString(1);
							if(checkDelAnswer.contains("1")) {
								asd.println("<script type=\"text/javascript\">"
										+ "const alertDel = () => alert(\"tento zaznam je uz spajane a pridane do spojovacej tabulky\")"
								+ "</script>");
								asd.println("<script type=\"text/javascript\">"
										+ "alertDel()"
								+ "</script>");							} 
							else {
								PreparedStatement del = con.prepareStatement("DELETE FROM "+table+" WHERE id = "+id+"");
								del.execute();
								del.close();
								con.close();
							};
					} catch (Exception ex) {
						asd.println(ex.toString());
					};
					doGet(request, response);
					break;
			case "edit":
				doGet(request, response);
					int rowCount = Integer.parseInt(toDo[3]);
					int colCount = Integer.parseInt(toDo[4]);

					rowCount++;
					String editRowExtra = "";
					for(int i=0; i<colCount+1;i++) {
						if(i == colCount) {
							int a = i+1;
							editRowExtra += "let editRowTd"+i+" = editRow.insertCell("+i+");"
									+ "editRowTd"+i+".innerHTML = \"<button  name=editBtn form=form2 class='btn btn-sm btn-outline-primary' type=submit value="+id+"-"+colCount+" href=displayTab1>Ulozit</button>\";";
							editRowExtra += "let editRowTd"+a+" = editRow.insertCell("+a+");"
								+ "editRowTd"+a+".innerHTML = \"<a class='btn btn-sm btn-outline-danger' href=displayTab1>X</a>\";";
						} else if(i == 0) {
							editRowExtra += "let editRowTd"+i+" = editRow.insertCell("+i+");"
									+ "editRowTd"+i+".innerHTML = \"<form id=form2  action=tab1Add method=post><input name=shit"+i+" form=form2 class=w-100 type=text></form>\";";
						} else {
							editRowExtra += "let editRowTd"+i+" = editRow.insertCell("+i+");"
									+ "editRowTd"+i+".innerHTML = \"<input name=shit"+i+" form=form2 class=w-100 type=text>\";";
						};
					};
					asd.println("<script type=\"text/javascript\">\n"
							+ "const addAddRow = () => {"
								+ "let table = document.getElementById(\"myTable\");"
								+ "let editRow = table.insertRow("+rowCount+");"
								+ editRowExtra
							+ "}"
						+"</script>");		
					asd.println("<script type=\"text/javascript\">"
								+ "addAddRow();"
						+ "</script>");
				break;
			case "add":
				doGet(request, response);
					String addRowExtra = "";
					for(int i=0; i<Integer.parseInt(id)+1;i++) {
						if(i == Integer.parseInt(id)) {
							int a = i+1;
							addRowExtra += "let addRowTd"+i+" = addRow.insertCell("+i+");"
										+ "addRowTd"+i+".innerHTML = \"<button  name=addBtn form=form1 class='btn btn-sm btn-outline-success' type=submit value="+id+"  href=displayTab1>Pridat</button>\";";
							addRowExtra += "let addRowTd"+a+" = addRow.insertCell("+a+");"
									+ "addRowTd"+a+".innerHTML = \"<a class='btn btn-sm btn-outline-danger' href=displayTab1>Naspat</a>\";";
						} else if(i==0) {
							addRowExtra += "let addRowTd"+i+" = addRow.insertCell("+i+");"
									+ "addRowTd"+i+".innerHTML = \"<form id=form1  action=tab1Add method=get><input name=shit"+i+" form=form1 class=w-100 type=text></form>\";";
						} else {
							addRowExtra += "let addRowTd"+i+" = addRow.insertCell("+i+");"
									+ "addRowTd"+i+".innerHTML = \"<input name=shit"+i+" form=form1 class=w-100 type=text>\";";
						}
					};
					asd.println("<script type=\"text/javascript\">\n"
								+ "const addAddRow = () => {"
									+ "let table = document.getElementById(\"myTable\");"
									+ "table.deleteRow(-1);"
									+ "let addRow = table.insertRow(-1);"
									+ addRowExtra
								+ "}"
							+"</script>");		
					asd.println("<script type=\"text/javascript\">"
									+ "addAddRow();"
							+ "</script>");
				break;
				default:
					doGet(request, response);
					break;
		};
	}
	public void getTabMd() {
		try {
			//ResultSet rs = stmt.executeQuery(command);
	//		md = rs.getMetaData();
		} catch(Exception ex) {
			ex.toString();
		};
	
	};
}
