package sk.ukf;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class tab1Add
 */
@WebServlet("/tab1Add")
public class tab1Add extends displayTab1 {
	private static final long serialVersionUID = 1L;
       int start = 0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public tab1Add() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter asd = response.getWriter();
		int dlzka = Integer.parseInt(request.getParameter("addBtn"));
		String updateVals = "";
		for(int i=0;i<dlzka;i++) {
			updateVals += request.getParameter("shit"+i+"")+"-";
		};
		String url = "jdbc:mysql://localhost/piatrik_sh";
		String login = "root";
		String pwd = "";
		String[] vals = updateVals.split("-");
		try {
			Connection con = DriverManager.getConnection(url, login, pwd);
			String sqlSetStrings = "";
			for(int i=0;i<dlzka;i++) {
				if(i==dlzka-1) {
					sqlSetStrings += "?";
				} else {
					sqlSetStrings += "?,";
				};
			};
			PreparedStatement insert = con.prepareStatement(""
					+ "INSERT INTO skladba (id, nazov, album, dlzka, interpret, hodnotenie)"
					+ "VALUES ("+sqlSetStrings+")");
			for(int i=0;i<dlzka;i++) {
				if(vals[i] == null || vals[i] == "") {
					insert.setString(i+1, "default");
				} else {
					insert.setString(i+1, vals[i]);
				}
			};
			asd.println(vals[0] + vals[1]);
			insert.execute();
		} catch (Exception ex) {
			asd.println(ex.toString());
		}
		RequestDispatcher rd = request.getRequestDispatcher("displayTab1");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		start = 0;
		PrintWriter asd = response.getWriter();
		String dlzky = request.getParameter("editBtn");
		String d[] = dlzky.split("-");
		int id = Integer.parseInt(d[0]);
		int dlzka = Integer.parseInt(d[1]);
		String updateVals = "";
		for(int i=0;i<dlzka;i++) {
			updateVals += request.getParameter("shit"+i+"")+"-";
		};
		String url = "jdbc:mysql://localhost/sh";
		String login = "root";
		String pwd = "";
		String[] vals = updateVals.split("-");
		//for(int i=0;i<vals.length;i++) {
		//	asd.println(vals[i]+" ");
		//};
		try {
			Connection con = DriverManager.getConnection(url, login, pwd);
			asd.println(md.getColumnCount());
			PreparedStatement insert = con.prepareStatement(""
					+ "UPDATE skladba "
					+ "SET "
					
					+ "id = "+tryVal(vals, dlzka, id)+","
					+ "nazov = "+tryVal(vals, dlzka, id)+","
					+ "album = "+tryVal(vals, dlzka, id)+","
					+ "dlzka = "+tryVal(vals, dlzka, id)+","
					+ "interpret = "+tryVal(vals, dlzka, id)+","
					+ "hodnotenie = "+tryVal(vals, dlzka, id)+" "
					
					+ "WHERE id ="+id);
		/*	for(int i=0;i<dlzka;i++) {
				if(vals[i] == null || vals[i] == "") {
					insert.setString(i+1, "DEFAULT");
				} else {
					insert.setString(i+1, vals[i]);
				}
			};*/
		// ->*************8	asd.println(insert.toString());
			insert.execute();
		} catch (Exception ex) {
			asd.println(ex.toString());
		}
//		RequestDispatcher rd = request.getRequestDispatcher("displayTab1");
	//	rd.forward(request, response);
	}
	public String tryVal(String[] vals, int dlzka, int id) {
		String output = "";
		for(int i = start;i<dlzka;i++) {
			if(vals[i] == String.valueOf(id)) {
				output =  String.valueOf(id);
			};
			if(vals[i] == null || vals[i] == "") {
				output = "DEFAULT";
			} else {
				output = vals[i];
			}
		};
		start++;
		return output;
	};

}